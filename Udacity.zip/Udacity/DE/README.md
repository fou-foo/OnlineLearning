# Data-Engieering-Nanodegree


## Set-up 

Create enviroment 

```bash 
conda create -n DE_udacity  python=3.6
conda activate DE_udacity 
conda install -c anaconda boto3
python -m pip install ipykernel
ipython kernel install --user --name=DE


```