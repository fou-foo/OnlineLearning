# Submit a package to PyPi


Example in the course `AWS Machine Learning Foundations Course`, lesson 4 OOP !
