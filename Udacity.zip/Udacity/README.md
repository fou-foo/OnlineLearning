# Udacity
Courses and programs done at Udacity


For exercises in `Lesson3` you need to installl `pytest`

```sh
pip install -U pytest
```

A funny and good Python's [book](https://docs.python-guide.org/)

We will try _to use a code lint_ [pylint](https://www.pylint.org/)

```{sh}
sudo apt-get install pylint #in ubuntu
```
