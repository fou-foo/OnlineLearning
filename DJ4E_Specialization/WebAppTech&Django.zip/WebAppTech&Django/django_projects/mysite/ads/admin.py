from django.contrib import admin
from .models import Ad
# Register your models here.
admin.site.register(Ad)